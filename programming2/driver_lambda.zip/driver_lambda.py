import time

import boto3

s3 = boto3.client('s3')


def driver_lambda(event, context):
    bucket_name = 'test-bucket-ws-999'

    # Create object assignment1.txt
    s3.put_object(Bucket=bucket_name, Key='assignment1.txt', Body='Empty Assignment 1')
    time.sleep(3)

    # Update object assignment1.txt
    s3.put_object(Bucket=bucket_name, Key='assignment1.txt', Body='Empty Assignment 2222222222')
    time.sleep(3)

    # Delete object assignment1.txt
    s3.delete_object(Bucket=bucket_name, Key='assignment1.txt')
    time.sleep(3)

    # Create object assignment2.txt
    s3.put_object(Bucket=bucket_name, Key='assignment2.txt', Body='33')
    time.sleep(3)