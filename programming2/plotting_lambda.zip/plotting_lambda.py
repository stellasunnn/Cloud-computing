import datetime
import io
import json
import boto3
from boto3.dynamodb.conditions import Key
from matplotlib import pyplot as plt

bucket_name = 'test-bucket-ws-999'
table_name = 'S3-object-size-history'

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')


def plotting_lambda(event, context):
    plot_key = 'plot'

    # Query DynamoDB for the last 10 seconds of dat
    end_time = int(datetime.now().timestamp())
    start_time = end_time - 10

    table = dynamodb.Table(table_name)
    response = table.query(
        KeyConditionExpression=Key('bucket_name').eq(bucket_name) & Key('timestamp').between(start_time, end_time),
        ScanIndexForward=True
    )

    timestamps = []
    sizes = []
    for item in response.get('Items', []):
        timestamps.append(datetime.fromtimestamp(int(item['timestamp'])))
        sizes.append(int(item['total_size']))

    # Query for the all-time maximum size
    max_size_response = table.query(
        KeyConditionExpression=Key('bucket_name').eq(bucket_name),
        ProjectionExpression='total_size',
        ScanIndexForward=False,
        Limit=1
    )

    # Determine the all-time maximum size
    if max_size_response.get('Items'):
        all_time_max = int(max_size_response['Items'][0]['total_size'])
    else:
        all_time_max = 0

    plt.figure(figsize=(10, 6))
    plt.plot(timestamps, sizes, marker='o', label='Recent Sizes')
    plt.axhline(y=all_time_max, color='r', linestyle='--', label='Historical High')
    plt.xlabel('Timestamp')
    plt.ylabel('Size (bytes)')
    plt.title('TestBucket Size Change (Last 10 Seconds)')
    plt.xticks(rotation=45)  # Rotate x-axis labels for better readability
    plt.legend()
    plt.tight_layout()

    # Save the plot to a bytes buffer
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)

    # Upload the plot to S3
    s3.put_object(Bucket=bucket_name, Key=plot_key, Body=buf.getvalue(), ContentType='image/png')

    return {
        'statusCode': 200,
        'body': json.dumps('Plot created and saved to S3')
    }
